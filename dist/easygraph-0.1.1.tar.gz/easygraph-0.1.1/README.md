# easyGraph

**easygraph** is a python library for plot graph networks.

## Functions

Full documentation soon. For now, take a look at *examples* folder.
